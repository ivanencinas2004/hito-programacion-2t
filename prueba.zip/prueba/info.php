<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="diseño.css">
    <title>Document</title>
</head>
<nav class="navbar navbar-dark bg-dark fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Bienvenido a nuestra web</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel">Bienvenido a nuestra web</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body">
        <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="formulario.php">Subir post</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="formregistro.php">Autenticar usuario</a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</nav>
<?php setcookie('ip', $_SERVER['REMOTE_ADDR']); 
?>
<?php setcookie('fecha', date('Y-m-d H:i:s')); 
?>
<body>
    <h1 style="display: flex; justify-content: center; ">Diferencias entre lenguajes</h1>
    <div class="titulo">
        <h3 style="display: flex; justify-content: center; text-align: center;">Formas de programacion
        </h3>
    </div>    
    <main>
        <div class="poo">
            <h2>Programacion oreintada a objetos</h2>
            <p>
                La programación orientada a objetos (POO) es un paradigma de
                programación que se basa en la creación de objetos, los cuales tienen un conjunto de atributos (datos) y
                métodos
                (acciones) que pueden ser invocados y manipulados desde otras partes del programa.
            </p>
        </div>
        <div class="poe">
            <h2>Programacion orientada a eventos</h2>
            <p>
                La programación orientada a eventos (POE) es un paradigma de programación que se centra en la interacción y
                respuesta a eventos. Un evento es una acción o suceso que ocurre en un sistema y en este tipo de
                programacion, el programa está diseñado
                para responder a estos eventos de forma automática, mediante la ejecución de código específico en respuesta
                a cada evento.
            </p>
        </div>
        <div class="lenguajes">
            <h2>Leguajes procedimentales</h2>
            <p>
                Los lenguajes de programación procedimentales son aquellos que se basan en la ejecución secuencial de
                instrucciones que se describen en una función o subrutina que pueden ser llamadas desde otras partes del
                programa. En este tipo de lenguajes, el programa se divide en bloques de código que se organizan en una
                jerarquía de funciones y procedimientos.
            </p>
        </div>
    </main>
    <div class="diferencias">
        <h2 style="text-align:center">Diferencias</h2>
        <p>
            POO se basa en la creacion de objetos que contienen tantos datos como funcionalidad mientras que la POE se centra en la respuesta a los eventos que ocurren en el sistema, y los lenguajes procedimentales se centra en procedimientos o funciones y su secuencia de ejecución. En cuanto a la reutilizacion de codigo, la POO permite la reutilización de código mediante la creación de clases y la herencia, mientras que en la programación procedimental, el código se reutiliza mediante la creación de funciones y su reutilización en diferentes partes del programa.
            En cuanto al poliformismo la POO permite la creación de múltiples implementaciones de una misma función, lo que se conoce como polimorfismo mientras que en la programación procedimental, una función solo tiene una única implementación.
        </p>
    </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>