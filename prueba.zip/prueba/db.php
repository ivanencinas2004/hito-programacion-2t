<?php
$conn=new PDO('mysql:host=localhost;dbname=hito_programacion', 'root', 'curso');
var_dump($conn)
?>